# -*- coding: utf-8 -*-
"""

Case Study: Forest residuals to jet fuel supply chain system in WA, OR, ID
A sample to assess supply chain resilience exposed to an earthquake scenario
Purpose: (a) to estimate the reduced capacity of facilities and edges based on the output data of HAZUS-MH
         (b) to generate the recovery time for each damaged facilities and edges, as well as the restorative cost
         (c) to obtain the time-varying capacity of facility and edge by combining the results of (a) and (b)


@author: Jie Zhao
"""



# import modules used in this code:
import numpy as np
import pandas as pd
from scipy.stats import poisson
from scipy.stats import uniform
from scipy.stats import lognorm
from scipy.stats import norm 
import random
import math

#=========================== HAZUS-MH data ===============================================================================
# Earthquake scenario: location = (-117.533, 45.536), depth = 3.4 km, magnitude = 5.24
# Conduct the scenario hazard analysis in HAZUS-MH software to obtain facility/bridge damage state probability
# Bridge damage state probability table 
data_bridge = pd.read_csv("Bridge_DS.txt")
Bridge_DS = pd. DataFrame (data_bridge)
Bridge_DS.columns = ['ID', 'None', 'Slight', 'Moderate', 'Extensive', 'Complete']
# Facility damage state probability table
data_facility = pd.read_csv("Facility_DS.txt")
Facility_DS = pd. DataFrame (data_facility)
Facility_DS.columns = ['ID', 'None', 'Slight', 'Moderate', 'Extensive', 'Complete']
N_facility = len (Facility_DS)
# for both "Bridge_DS" and "Faciliry_DS":
# - Column 1: the structure ID 
# - Column 2-6: the probability of structure in damage state 0, 1, 2, 3, and 4 respectively.

#===========================(a) Estimate the reduced capacity of facilities and edges===================================
print("Estimate the reduced capacity of facilities")
# 1. Estimate the reduced capacity for facilities-----------------------------------------------------------------------

# --------------------Input----------------------------------
# Relationship between facility damage state and facility functionality for DS1-4
# obtained from Table 15.27, in HAZUS earthquake technique mannual
GFT_damage_ratio = [0.09,0.23,0.78,1] 

#----------------------Variables ------------------------------- 
# Damage state of facility
# row (facility), 
# column (ID,damage state: 0-4)
DamageState_facility = np.zeros((N_facility, 2)) 

# Capacitry matrix for facility with following earthquake scenario
# row (facility), 
# column (ID,remaining capacity following earthquake)
facility_cap = np.ones((len(Facility_DS), 2))

for i in range(len(Facility_DS)):#only consider the damage for GFT facility
    facility_cap [i][0] = Facility_DS.values[i][0]# the 1st column is the bridge ID    

    R_random = random.random()
    if R_random > 1- Facility_DS.values[i][1]:
        # Damage state: 0
        DamageState_facility[i][1] = 0
        facility_cap[i][1] = 1
    elif 1- Facility_DS.values[i][1] - Facility_DS.values[i][2] < R_random <= 1- Facility_DS.values[i][1]:
        # Damage state: 1
        DamageState_facility[i][1] = 1
        facility_cap[i][1] = 1-GFT_damage_ratio[0]
    elif  1- Facility_DS.values[i][1] - Facility_DS.values[i][2] - Facility_DS.values[i][3] < R_random <= 1- Facility_DS.values[i][1]- Facility_DS.values[i][2]:
        # Damage state: 2
        DamageState_facility[i][1] = 2
        facility_cap[i][1] = 1-GFT_damage_ratio[1]
    elif 1- Facility_DS.values[i][1] - Facility_DS.values[i][2] - Facility_DS.values[i][3] - Facility_DS.values[i][4] < R_random <= 1- Facility_DS.values[i][1] - Facility_DS.values[i][2] - Facility_DS.values[i][3]:
        # Damage state: 3
        DamageState_facility[i][1] = 3
        facility_cap[i][1] = 1-GFT_damage_ratio[2]
    else:
        DamageState_facility[i][1] = 4
        # Damage state: 4
        facility_cap[i][1] = 1-GFT_damage_ratio[3]
        
        
        
# 2. Estimate the reduced capacity for edges-----------------------------------------------------------------
print("Estimate the reduced capacity of edges")      
# ---------------------Load bridge and edge TXT files--------------------
data_bridge = pd.read_csv("HighwayBridge_3state.txt")
bridge = pd. DataFrame (data_bridge)
data_Bridge_Edge = pd.read_csv("Relationship_BridgeRoad_3state.txt")
relationship = pd. DataFrame (data_Bridge_Edge) 
data_edge = pd.read_csv("MiddlePoint_Road.txt")
edge = pd. DataFrame (data_edge) 

N_bridge = len(bridge) # Tatal amount of bridges
N_edge = len(edge) # Tatal amount of edges   
   
#----------------------Variables----------------------------------------
# Damage index matrix for bridges
# row (bridge), 
# column (bridge ID,remaining capacity following earthquake)
BDI = np.zeros((N_bridge, 2))
# Damage state of bridge
DamageState_bridge = np.zeros((N_bridge, 2))
# Capacity matrix for edges
# row (edge), 
# column (edge ID,remaining capacity following earthquake)
edge_cap = np.ones((N_edge, 2))
# Link Damage Index :LDI
LDI = np.zeros((N_edge, 2))

# Obtain BDI (Bridge damage index) based on the relationship between BDI and bridge damage state
for i in range (len(Bridge_DS)):
    R_random =random.random()
    if R_random >  1- Bridge_DS.values[i][1]:
        DamageState_bridge[i][1] = 0
        BDI[i][1] = 0
    elif 1- Bridge_DS.values[i][1]- Bridge_DS.values[i][2] < R_random <= 1- Bridge_DS.values[i][1]:
        DamageState_bridge[i][1] = 1
        BDI[i][1] = 0.1
    elif 1- Bridge_DS.values[i][1]- Bridge_DS.values[i][2]- Bridge_DS.values[i][3] < R_random <= 1- Bridge_DS.values[i][1]- Bridge_DS.values[i][2]:
        DamageState_bridge[i][1] = 2
        BDI[i][1] = 0.3
    elif 1- Bridge_DS.values[i][1]- Bridge_DS.values[i][2]- Bridge_DS.values[i][3]- Bridge_DS.values[i][4] < R_random <= 1- Bridge_DS.values[i][1]- Bridge_DS.values[i][2]- Bridge_DS.values[i][3]:
        DamageState_bridge[i][1] = 3
        BDI[i][1] = 0.75
    else:
        DamageState_bridge[i][1] = 4
        BDI[i][1] = 1

# Gnenerate the LDI (Link Damage Index) and related edge capacity 
for i in range(N_edge):
    edge_cap [i][0] = edge.values[i][1] 
    LDI[i][0] = edge.values[i][1] 
    temp_index = edge.values[i][1] 
    temp_relation = relationship.loc[relationship.FID_road == temp_index]
    if temp_relation.shape[0] == 0:
        LDI[i][1] = 0
    else:
        bridge_tem_damage_index = 0
        for h in range (temp_relation.shape[0]):
            bridge_id = temp_relation.shape[0] - 1 
            bridge_tem_damage_index = bridge_tem_damage_index + (BDI[temp_relation.values[h][11]][1]**2)
            # calculate Link Damage Index (LDI)
        LDI[i][1] = math.sqrt(bridge_tem_damage_index)                
    # Changes in Link capacity as Function of Link Damage Index, based on following relationship (Shiraki et al., 2007):
    # capacity=0.5 --- 1.5 < LDI 
    # capacity=0.5 --- 1.0 < LDI <= 1.5
    # capacity=0.75 --- 0.5 < LDI <= 1.0
    # capacity=1 --- otherwise
    if LDI[i][1] > 1.5:
        edge_cap[i][1] = 0.5*edge_cap[i][1]
    elif 1.0 <= LDI[i][1] < 1.5:
        edge_cap[i][1] = 0.5*edge_cap[i][1]
    elif 0.5 <= LDI[i][1] < 1.0:
        edge_cap[i][1] = 0.75*edge_cap[i][1]
    else:
        edge_cap[i][1] = edge_cap[i][1]

#=======================(b) Generate the recovery time/cost for each damaged facilities and edges ========================
print("Generate the recovery time for each damaged facilities and edges")
# ------------------------Bridge restoration function (Normal distribution)----------------
# bridge continuous restoration functions, row(DS1-4), column (mu and std)
# obtained from Table 7.7, in HAZUS earthquake technique mannual,unit: days
bridge_repair_time = [[0.6,0.6],
                        [2.5,2.7],
                        [75,42],
                        [230,110]]                  
                  
# bridge repair downtime for DS1-4, 
# obtained from Hashemi et al.(2019), unit: days
bridge_repair_downtime = [20,60,60,100]

#-------------------Facility restoration function (Normal distribution)--------------------------
# GFT continuous restoration functions, row(DS1-4), column (mu and std)
# obtained from Table 8.20, in HAZUS earthquake technique mannual,unit: days
GFT_repair_time = [[0.4,0.1],
                   [3.0,2.2],
                   [14,12],
                   [190,80]]


# GFT facility repair downtime
# obtained from Almufti and Willford (2013), unit: days

# Inspection time (Longnormal distribution): row (DS1-4), column (mu, beta)
inspection_time = [[5,0.54],
                   [5,0.54],
                   [5,0.54],
                   [5,0.54]]

# Engineering Mobilization and Review/Redesign (Longnormal distribution): row (DS1-4), column (mu, beta)
eng_time = [[6,0.4],
            [12,0.4],
            [12,0.4],
            [50,0.32]]

# Financing with insurance (Longnormal distribution): row (DS1-4), column (mu, beta)
fin_time = [[6,1.11],
            [6,1.11],
            [6,1.11],
            [6,1.11]]
# Contractor Mobilization (Longnormal distribution): row (DS1-4), column (mu, beta)
con_time = [[11,0.43],
            [11,0.43],
            [23,0.41],
            [23,0.41]]
 
# Permitting (Longnormal distribution): row (DS1-4), column (mu, beta)
per_time = [[1,0.86],
            [1,0.86],
            [8,0.32],
            [8,0.32]]


#-----------------------Variables for output------------------------
    # repair time for facility and bridge:
repair_time_bridge = np.zeros((N_bridge, 2))#unit: days
repair_time_edge = np.zeros((N_edge, 2))#unit: days
repair_time_facility = np.zeros((N_facility, 2))#unit: days

# repair cost for facility:
repair_cost_facility = np.zeros((N_facility, 2))#unit: $


# Calculate the repair time for bridges:
for i in range(N_bridge):
    repair_time_bridge [i][0]= Bridge_DS.values[i][0]# the 1st column is the bridge ID   
    if DamageState_bridge[i][1] == 1:
        repair_time_bridge [i][1] = abs(norm.rvs(bridge_repair_time[0][0], bridge_repair_time[0][1], 1))+bridge_repair_downtime[0]                    
    elif DamageState_bridge[i][1] == 2:
        repair_time_bridge [i][1] = abs(norm.rvs(bridge_repair_time[1][0], bridge_repair_time[1][1], 1))+bridge_repair_downtime[1]
    elif DamageState_bridge[i][1] == 3:
        repair_time_bridge [i][1] = abs(norm.rvs(bridge_repair_time[2][0], bridge_repair_time[2][1], 1))+bridge_repair_downtime[2]
    elif DamageState_bridge[i][1] == 4:
        repair_time_bridge [i][1] = abs(norm.rvs(bridge_repair_time[3][0], bridge_repair_time[3][1], 1))+bridge_repair_downtime[3]

print("Generate the repair time for edges")
# Calculate the repair time for edges:
for i in range(N_edge):
    repair_time_edge [i][0] = edge.values[i][1]  
    temp_index = edge.values[i][1] 
    temp_relation = relationship.loc[relationship.FID_road == temp_index]
    if temp_relation.shape[0] == 0:
        repair_time_edge [i][1] = 0
    else:
        edge_tem_repair_index = 0
        for h in range (temp_relation.shape[0]):
            bridge_id = temp_relation.shape[0] - 1 
            edge_tem_repair_index = max(edge_tem_repair_index, repair_time_bridge[temp_relation.values[h][11]][1]) 
        repair_time_edge [i][1] = edge_tem_repair_index

print("Generate the repair time for facilities")
# Calculate the repair time for facility:
for i in range(N_facility):
    repair_time_facility [i][0] = facility_cap[i][0] # the 1st column is the facilty ID 
    if DamageState_facility[i][1] == 1:
        # downtime:
        seq1 = abs(lognorm.rvs(inspection_time[0][1],0,inspection_time[0][0], 1)) + abs(lognorm.rvs(fin_time[0][1],0, fin_time[0][0], 1))
        seq2 = abs(lognorm.rvs(inspection_time[0][1],0, inspection_time[0][0], 1)) + abs(lognorm.rvs(eng_time[0][1],0,eng_time[0][0], 1))
        abs(lognorm.rvs(per_time[0][1],0, per_time[0][0], 1))
        seq3 = abs(lognorm.rvs(inspection_time[0][1], 0, inspection_time[0][0], 1))+abs(lognorm.rvs(con_time[0][1], 0, con_time[0][0], 1))
        GFT_delay_time = max(seq1,seq2,seq3)
        repair_time_facility [i][1] = abs(norm.rvs(GFT_repair_time[0][0], GFT_repair_time[0][1], 1))+GFT_delay_time                   
    elif DamageState_facility[i][1] == 2:
        # downtime:
        seq1 = abs(lognorm.rvs(inspection_time[1][1],0,inspection_time[1][0], 1)) + abs(lognorm.rvs(fin_time[1][1],0, fin_time[1][0], 1))
        seq2 = abs(lognorm.rvs(inspection_time[1][1],0,inspection_time[1][0], 1)) + abs(lognorm.rvs(eng_time[1][1],0,eng_time[1][0], 1))
        abs(lognorm.rvs(per_time[1][1],0, per_time[1][0], 1))
        seq3 = abs(lognorm.rvs(inspection_time[1][1], 0, inspection_time[1][0], 1))+abs(lognorm.rvs(con_time[1][1], 0, con_time[1][0], 1))
        GFT_delay_time = max(seq1,seq2,seq3)
        repair_time_facility [i][1] = abs(norm.rvs(GFT_repair_time[1][0], GFT_repair_time[1][1], 1))+GFT_delay_time 
    elif DamageState_facility[i][1] == 3:
        # downtime:
        seq1 = abs(lognorm.rvs(inspection_time[2][1],0,inspection_time[2][0], 1)) + abs(lognorm.rvs(fin_time[2][1],0, fin_time[2][0], 1))
        seq2 = abs(lognorm.rvs(inspection_time[2][1],0,inspection_time[2][0], 1)) + abs(lognorm.rvs(eng_time[2][1],0,eng_time[2][0], 1))
        abs(lognorm.rvs(per_time[2][1],0, per_time[2][0], 1))
        seq3 = abs(lognorm.rvs(inspection_time[2][1], 0, inspection_time[2][0], 1))+abs(lognorm.rvs(con_time[2][1], 0, con_time[2][0], 1))
        GFT_delay_time = max(seq1,seq2,seq3)
        repair_time_facility [i][1] = abs(norm.rvs(GFT_repair_time[2][0], GFT_repair_time[2][1], 1))+GFT_delay_time 
    elif DamageState_facility[i][1] == 4:
        # downtime:
        seq1 = abs(lognorm.rvs(inspection_time[3][1],0,inspection_time[3][0], 1)) + abs(lognorm.rvs(fin_time[3][1],0, fin_time[3][0], 1))
        seq2 = abs(lognorm.rvs(inspection_time[3][1],0,inspection_time[3][0], 1)) + abs(lognorm.rvs(eng_time[3][1],0,eng_time[3][0], 1))
        abs(lognorm.rvs(per_time[3][1],0, per_time[3][0], 1))
        seq3 = abs(lognorm.rvs(inspection_time[3][1], 0, inspection_time[3][0], 1))+abs(lognorm.rvs(con_time[3][1], 0, con_time[3][0], 1))
        GFT_delay_time = max(seq1,seq2,seq3)
        repair_time_facility [i][1] = abs(norm.rvs(GFT_repair_time[3][0], GFT_repair_time[3][1], 1))+GFT_delay_time 


# Total repair time
total_repair_time = int( max(max(repair_time_facility[:,1]), max(repair_time_edge[:,1])))# unit: days
total_repair_week = int(total_repair_time/int(7)) # unit: week

#------------------------------------------Repair cost-------------------------------------------
print("Generate the recovery cost")
# Restoration cost for facility for DS1-4
# obtained from Table 15.3, in HAZUS earthquake technique mannual,unit: % of investment cost
repair_cost_ratio = [1.4,7.2,21.8,72.5]
GFT_investment = 433000000 # unit: $
GFT_repair_cost = np.zeros(4)
for i in range(len(GFT_repair_cost)):
    GFT_repair_cost[i] = (GFT_investment/100)*repair_cost_ratio[i]

# calculate the daily repair cost for each facility:
for i in range(N_facility):
    repair_cost_facility [i][0]= facility_cap[i][0] # the 1st column is the facilty ID 
    if DamageState_facility[i][1] == 1:
        repair_cost_facility [i][1] = GFT_repair_cost[0]/(repair_time_facility[i][1]+0.001)
    elif DamageState_facility[i][1] == 2:
        repair_cost_facility [i][1] = GFT_repair_cost[1]/(repair_time_facility[i][1]+0.001)
    elif DamageState_facility[i][1] == 3:
        repair_cost_facility [i][1] = GFT_repair_cost[2]/(repair_time_facility[i][1]+0.001)
    elif DamageState_facility[i][1] == 4:
        repair_cost_facility [i][1] = GFT_repair_cost[3]/(repair_time_facility[i][1]+0.001) 



# calculate the weekly repair cost for all facilities:                    
# Total weekly repair cost:
repair_costs = np.zeros((total_repair_week+1))#unit: $

for i in range(total_repair_week):
    for f in range (N_facility):
        temp_day = int(7*i)
        if temp_day <= repair_time_facility[f][1]:
            repair_costs[i+1] = repair_costs[i+1] + repair_cost_facility[f][1]*7
        

#==============================(c)Time-varying facility/edge capacity=================================
# Weekly basis time-varying capacity 
# row: facility/edge ID, column: facility/edge capacity index at each week

# Earthquake occurs at the begining of second week
facility_time_varying_cap = np.ones((N_facility, total_repair_week+1))
edge_time_varying_cap = np.ones((N_facility, total_repair_week+1))

for i in range(total_repair_week):
    for f in range (N_facility):
        temp_day = int(7*i)
        if temp_day < repair_time_facility[f][1]:
            facility_time_varying_cap[f][i+1] = facility_cap[f][1] 

for i in range(total_repair_week):
    for e in range (N_edge):
        temp_day = int(7*i)
        if temp_day < repair_time_edge[e][1]:
            edge_time_varying_cap[f][i+1] = edge_cap[e][1] 


np.save("total_repair_week.npy", total_repair_week)
np.save("facility_time_varying_cap.npy", facility_time_varying_cap)
np.save("edge_time_varying_cap.npy", edge_time_varying_cap)
np.save("repair_costs.npy",repair_costs)
#np.save("repair_time_edge", repair_time_edge)
#np.save("repair_time_facility",repair_time_facility) 
#np.save("total_repair_time", total_repair_time)
#np.save("facility_cap.npy", facility_cap)
#np.save("edge_cap.npy", edge_cap)






        
        
                 
